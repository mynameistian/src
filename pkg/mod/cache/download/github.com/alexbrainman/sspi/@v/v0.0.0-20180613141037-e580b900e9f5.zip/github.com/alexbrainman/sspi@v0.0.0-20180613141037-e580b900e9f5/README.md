This repository holds Go packages for accessing Security Support Provider Interface on Windows. 
