package main

import (
	"github.com/gogf/gf/util/gutil"
)

func main() {
	gutil.Dump(map[interface{}]interface{}{
		1: "john",
	})
}
